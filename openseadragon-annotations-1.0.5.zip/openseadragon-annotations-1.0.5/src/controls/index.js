import Move from './Move';
import Draw from './Draw';

export default [
  Move,
  Draw,
];
